﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Abstraction
{
    abstract class AbstractHandler
    {
        public virtual void Open(Document doc)
        {
            FileStream fs;
            StreamReader fr;

            fs = new FileStream(doc.DocPath, FileMode.Open, FileAccess.Read);
            fr = new StreamReader(fs);

            string content = fr.ReadToEnd();

            Console.WriteLine("Text of Document {0}", content);
        }
        public virtual void Create()
        {

        }
        public virtual void Change()
        {

        }
        public virtual void Save()
        {

        }
    }
}
