﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstraction
{
    enum DocType { doc, txt, xml, undef } ;

    class Program
    {
        static void Main(string[] args)
        {

            Document doc1 = new Document("D:\\Test1.txt");
            Document doc2 = new Document("D:\\Test2.xml");
            Document doc3 = new Document("D:\\Test3.docx");

            TXTHandler txth = new TXTHandler();
            DocHandler doch = new DocHandler();
            XMLHandler xmlh = new XMLHandler();

            txth.Open(doc1);
            doch.Open(doc3);
            xmlh.Open(doc2);

            Console.ReadLine();

        }
    }
}
